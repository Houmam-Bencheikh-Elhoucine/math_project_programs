IMPORTANT!!!

- This font is for PERSONAL USE ONLY, NO COMMERCIAL USE ALLOWED!

- If you want to purchase Full Version and Commercial Use here is
  the link :
  NOTE:

- This font is for PERSONAL USE ONLY, NO COMMERCIAL USE ALLOWED!!!

- If you want to purchase Full Version and Commercial Use here is the link :
  https://zarmatype.com/font/bulbis/

- For Corporate use you have to purchase Corporate license

- Any donation are very appreciated. Paypal account for donation :
  https://paypal.me/zarmatype

- If you need a custom license please contact us at
  admin@zarmatype.com

- Please visit our store for more unique fonts :
  https://zarmatype.com/

- Follow our instagram for update : @zarma.type

THANKYOU

- For Corporate use you have to purchase Corporate license

- Any donation are very appreciated. Paypal account for donation :
  https://paypal.me/zarmatype

- If you need a custom license please contact us at
  admin@zarmatype.com

- Please visit our store for more amazing fonts :
  https://zarmatype.com/

- Follow our instagram for update : @zarma.type


Thank you

_____________________________________________________________________________

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti
dan menyetujui semua syarat dan ketentuan penggunaan
font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan
  "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang
   sifatnya tidak "komersil", alias tidak menghasilkan profit
   atau keuntungan dari hasil memanfaatkan/menggunakan font kami.
   Baik itu untuk individu, Agensi Desain Grafis, Percetakan,
   Distro atau Perusahaan/Korporasi.   

- Silakan gunakan lisensi komersial dengan membeli melalui link ini :
  https://zarmatype.com/font/fontname/

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan
  atau memanfaatkan font ini untuk kepeluan Komersial,
  baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics,
  Youtube, Desain kaos distro atau untuk Kemasan Produk
  (baik Fisik ataupun Digital) atau Media apapun dengan
  tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan
  menggunakan Corporate License.

- Menggunakan font ini dengan lisensi "Personal Use" untuk
  kepentingan Komersial apapun bentuknya TANPA IZIN dari kami,
  akan dikenakan biaya CORPORATE LICENSE.

- Silahkan kunjungi toko kami untuk melihat lebih banyak font-
  font yang unik di :
  https://zarmatype.com/

- Informasi tentang Lisensi apa yang akan anda perlukan,
  silahkan menghubungi email kami di:
  admin@zarmatype.com

Terima kasih.